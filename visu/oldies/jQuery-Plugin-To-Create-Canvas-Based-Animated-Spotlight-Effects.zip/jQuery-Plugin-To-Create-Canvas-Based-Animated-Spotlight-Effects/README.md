# jQuery Spotlight

## About
Provides a simple spotlight effect on an element in the DOM.

Original plugin was created by Gilbert Pellegrom. I have tweaked this version to iron out some bugs and continue maintenance of this plugin.

## Requirements
Master & 2.x - support jQuery 2.0 and IE9+ only.

1.x - support for jQuery < 2.0 and IE7/8.

## License
Licensed under the GPL license (http://www.gnu.org/licenses/gpl-3.0.html)
